#include "menuEnigme.h"
#include "scores.h"

Mix_Chunk *clicSound = NULL;

void afficherMenu(SDL_Surface *ecran, char *texteSaisi, int *quitter, int *saisieActive) {
    // Charger l'image de fond
    SDL_Surface *background = IMG_Load("backgroundmenu.png");
    if (background == NULL) {
        fprintf(stderr, "Erreur lors du chargement de l'image de fond: %s\n", IMG_GetError());
        return;
    }

    // Charger l'image line_edit.png
    SDL_Surface *lineEdit = IMG_Load("line_edit.png");
    if (lineEdit == NULL) {
        fprintf(stderr, "Erreur lors du chargement de line_edit.png: %s\n", IMG_GetError());
        SDL_FreeSurface(background);
        return;
    }

    // Charger l'image valider.png
    SDL_Surface *valider = IMG_Load("valider.png");
    if (valider == NULL) {
        fprintf(stderr, "Erreur lors du chargement de valider.png: %s\n", IMG_GetError());
        SDL_FreeSurface(background);
        SDL_FreeSurface(lineEdit);
        return;
    }

    // Centrer les éléments
    int ecranWidth = ecran->w;
    int ecranHeight = ecran->h;

    // Positionner line_edit.png au centre
    SDL_Rect lineEditPos = {
        (ecranWidth - lineEdit->w) / 2, // Centré horizontalement
        (ecranHeight - lineEdit->h) / 2 - 50, // Décalé vers le haut
        0, 0
    };

    // Positionner valider.png sous line_edit.png
    SDL_Rect validerPos = {
        (ecranWidth - valider->w) / 2, // Centré horizontalement
        lineEditPos.y + lineEdit->h + 20, // 20 pixels sous line_edit.png
        0, 0
    };

    // Afficher l'image de fond
    SDL_BlitSurface(background, NULL, ecran, NULL);

    // Afficher le texte "Donner votre nom/pseudonyme"
    TTF_Init();
    TTF_Font *font = TTF_OpenFont("Arial.ttf", 24);
    if (font == NULL) {
        fprintf(stderr, "Erreur lors du chargement de la police: %s\n", TTF_GetError());
    } else {
        SDL_Color textColor = {255, 255, 255}; // Couleur du texte (blanc)
        SDL_Surface *textSurface = TTF_RenderText_Solid(font, "Donner votre nom/pseudonyme", textColor);
        SDL_Rect textPos = {
            (ecranWidth - textSurface->w) / 2, // Centré horizontalement
            lineEditPos.y - 40, // 40 pixels au-dessus de line_edit.png
            0, 0
        };
        SDL_BlitSurface(textSurface, NULL, ecran, &textPos);
        SDL_FreeSurface(textSurface);
        TTF_CloseFont(font);
    }
    TTF_Quit();

    // Afficher line_edit.png
    SDL_BlitSurface(lineEdit, NULL, ecran, &lineEditPos);

    // Afficher valider.png
    SDL_BlitSurface(valider, NULL, ecran, &validerPos);

    // Afficher le texte saisi dans la zone line_edit.png
    if (strlen(texteSaisi) > 0) {
        TTF_Init();
        TTF_Font *font = TTF_OpenFont("Arial.ttf", 24);
        if (font == NULL) {
            fprintf(stderr, "Erreur lors du chargement de la police: %s\n", TTF_GetError());
        } else {
            SDL_Color textColor = {255, 255, 255}; // Couleur du texte (blanc)
            SDL_Surface *textSurface = TTF_RenderText_Solid(font, texteSaisi, textColor);
            SDL_Rect textPos = {
                lineEditPos.x + 30, // Décalage de 10 pixels à l'intérieur de line_edit.png
                lineEditPos.y + (lineEdit->h - textSurface->h) / 2, // Centré verticalement
                0, 0
            };
            SDL_BlitSurface(textSurface, NULL, ecran, &textPos);
            SDL_FreeSurface(textSurface);
            TTF_CloseFont(font);
        }
        TTF_Quit();
    }

    // Afficher le curseur (s'il y a du texte saisi)
    if (*saisieActive) {
        int positionCurseur = strlen(texteSaisi); // Position du curseur à la fin du texte

        // Charger le curseur
        SDL_Surface *curseur = SDL_CreateRGBSurface(0, 2, 30, 32, 0, 0, 0, 0); // Un simple rectangle pour le curseur
        SDL_FillRect(curseur, NULL, SDL_MapRGB(curseur->format, 255, 255, 255)); // Curseur blanc

        // Calculer la position du curseur dans la zone
        SDL_Rect curseurPos = {
            lineEditPos.x + 30 + positionCurseur * 14, // Décalage pour chaque caractère (environ 14px par caractère)
            lineEditPos.y + (lineEdit->h - curseur->h) / 2, // Centré verticalement
            0, 0
        };

        // Afficher le curseur
        SDL_BlitSurface(curseur, NULL, ecran, &curseurPos);
        SDL_FreeSurface(curseur);
    }

    // Libérer les surfaces
    SDL_FreeSurface(background);
    SDL_FreeSurface(lineEdit);
    SDL_FreeSurface(valider);

    // Mettre à jour l'écran
    SDL_Flip(ecran);
}

void gererEvenements(SDL_Event event, int *quitter, char *texteSaisi, int *saisieActive, int *afficherScoresFlag, SDL_Surface *ecran, Mix_Chunk *clicSound) {
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                *quitter = 1;
                break;

            case SDL_MOUSEBUTTONDOWN:
                // Obtenir les dimensions de l'écran
                int ecranWidth = ecran->w;
                int ecranHeight = ecran->h;

                // Charger les images pour obtenir leurs dimensions
                SDL_Surface *lineEdit = IMG_Load("line_edit.png");
                SDL_Surface *valider = IMG_Load("valider.png");

                // Calculer les positions de line_edit.png et valider.png
                SDL_Rect lineEditPos = {
                    (ecranWidth - lineEdit->w) / 2, // Centré horizontalement
                    (ecranHeight - lineEdit->h) / 2 - 50, // Décalé vers le haut
                    lineEdit->w,
                    lineEdit->h
                };

                SDL_Rect validerPos = {
                    (ecranWidth - valider->w) / 2, // Centré horizontalement
                    lineEditPos.y + lineEdit->h + 20, // 20 pixels sous line_edit.png
                    valider->w,
                    valider->h
                };

                // Vérifier si le clic est sur le bouton valider.png
                if (event.button.x >= validerPos.x && event.button.x <= validerPos.x + validerPos.w &&
                    event.button.y >= validerPos.y && event.button.y <= validerPos.y + validerPos.h) {
                    printf("Bouton Valider cliqué !\n");

                    // Jouer le son de clic
                    if (clicSound) {
                        Mix_PlayChannel(-1, clicSound, 0); // Jouer le son une fois
                    }

                    if (strlen(texteSaisi) > 0) { // Vérifier si du texte a été saisi
                        ajouterScore(texteSaisi); // Ajouter le texte saisi aux scores
                        texteSaisi[0] = '\0'; // Réinitialiser la zone de texte
                        *afficherScoresFlag = 1; // Activer l'affichage des scores
                        afficherScores(); // Afficher les scores mis à jour
                    }
                }

                // Vérifier si le clic est sur la zone line_edit.png
                if (event.button.x >= lineEditPos.x && event.button.x <= lineEditPos.x + lineEditPos.w &&
                    event.button.y >= lineEditPos.y && event.button.y <= lineEditPos.y + lineEditPos.h) {
                    *saisieActive = 1; // Activer la saisie
                } else {
                    *saisieActive = 0; // Désactiver la saisie
                }

                // Libérer les surfaces
                SDL_FreeSurface(lineEdit);
                SDL_FreeSurface(valider);
                break;

            case SDL_KEYDOWN:
                // Si l'utilisateur appuie sur "e", afficher les scores
                if (event.key.keysym.sym == SDLK_e) {
                    printf("Touche 'E' pressée ! Affichage des scores...\n");
                    afficherScores();
                }

                if (*saisieActive) {
                    // Gérer la saisie de texte
                    if (event.key.keysym.sym == SDLK_BACKSPACE && strlen(texteSaisi) > 0) {
                        texteSaisi[strlen(texteSaisi) - 1] = '\0'; // Supprimer le dernier caractère
                    } else if (event.key.keysym.sym == SDLK_RETURN) {
                        // Ajouter le texte saisi aux scores lorsque l'utilisateur appuie sur Entrée
                        if (strlen(texteSaisi) > 0) { // Vérifier si du texte a été saisi
                            ajouterScore(texteSaisi); // Ajouter le texte saisi aux scores
                            texteSaisi[0] = '\0'; // Réinitialiser la zone de texte
                            *afficherScoresFlag = 1; // Activer l'affichage des scores
                            afficherScores(); // Afficher les scores mis à jour
                        }
                    } else if (strlen(texteSaisi) < 50) { // Limite de 50 caractères
                        char caractere = (char)event.key.keysym.sym;
                        if (caractere >= 32 && caractere <= 126) { // Caractères ASCII imprimables
                            strncat(texteSaisi, &caractere, 1);
                        }
                    }
                }
                break;
        }
    }
}
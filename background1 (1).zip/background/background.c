#include "background.h"

void initbackground(Background *B)
{
    int imgFlags = IMG_INIT_PNG|IMG_INIT_JPG;
    if(!(IMG_Init(imgFlags) & imgFlags)) {
        printf("SDL_image n'a pas pu s'initialiser! SDL_image Error: %s\n", IMG_GetError());
        exit(EXIT_FAILURE);
    }

    B->Bg_IMG = IMG_Load("background.png");
    if(!B->Bg_IMG) {
        printf("Erreur de chargement du background : %s\n", IMG_GetError());
        exit(EXIT_FAILURE);
    }

    B->Pos.x = 0;
    B->Pos.y = 0;
    B->cam.x = 0;
    B->cam.y = 0;
    B->cam.w = SCREEN_W;
    B->cam.h = SCREEN_H;

    B->frame = 0;
    B->Posanim.x = 0;
    B->Posanim.y = 0;

    B->music = Mix_LoadMUS("music.ogg");
    if(!B->music) {
        printf("Erreur de chargement de la musique : %s\n", Mix_GetError());
    }
}

void afficherbackground(Background *B, SDL_Surface *ecran)
{
    SDL_BlitSurface(B->Bg_IMG, &B->cam, ecran, &B->Pos);
}

void animerbackground(Background *B, SDL_Surface *ecran)
{
    B->frame++;
    if(B->frame >= 50) B->frame = 0;
    SDL_BlitSurface(B->anim[B->frame], NULL, ecran, &B->Posanim);
}

void gererMenuValidation(SDL_Surface *ecran, char *nomJoueur) {
    // Ajouter le score du joueur
    ajouterScore(nomJoueur);
    
    // Afficher les scores
    afficherScores();
    
    // Vous pouvez ajouter ici d'autres logiques de retour au menu principal
}

void recupererClavier(SDL_Surface *ecran,clavier *c, int *continuer, int *menuActif, char *texte, int tailleTexte) 
{
    SDL_Event event;
    while (SDL_PollEvent(&event)) 
    {
        switch (event.type) 
        {
            case SDL_QUIT:
                *continuer = 0;
                break;
                
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym) 
                {
                    case SDLK_LEFT:   c->Gauche = 1; break;  // Correction de la casse (Gauche -> gauche)
                    case SDLK_RIGHT:  c->droite = 1; break;
                    case SDLK_UP:     c->haut = 1; break;
                    case SDLK_DOWN:   c->bas = 1; break;
                    case SDLK_ESCAPE: c->echap = 1; break;
                    case SDLK_g:      c->echap = 1; break;
                    case SDLK_e:      c->e = 1; *menuActif = 1; break;  // Correction: e = 1 au lieu de 0
                    
                    case SDLK_BACKSPACE:
                        if (strlen(texte) > 0) {
                            texte[strlen(texte) - 1] = '\0';
                        }
                        break;
                    
                    case SDLK_RETURN:  // Touche Entrée/Valider
                        if (strlen(texte) > 0) {
                            gererMenuValidation(ecran, texte);
                            texte[0] = '\0';  // Réinitialiser le texte
                        }
                        break;

                    // Saisie texte plus efficace
                    default:
                        if (event.key.keysym.sym >= SDLK_a && event.key.keysym.sym <= SDLK_z) {
                            if (strlen(texte) < tailleTexte - 1) {
                                char lettre = 'a' + (event.key.keysym.sym - SDLK_a);
                                strncat(texte, &lettre, 1);
                            }
                        }
                        else if (event.key.keysym.sym == SDLK_SPACE) {
                            if (strlen(texte) < tailleTexte - 1) {
                                strncat(texte, " ", 1);
                            }
                        }
                        break;
                }
                break;
                
            case SDL_KEYUP:
                switch (event.key.keysym.sym) 
                {
                    case SDLK_LEFT:   c->Gauche = 0; break;
                    case SDLK_RIGHT:  c->droite = 0; break;
                    case SDLK_UP:     c->haut = 0; break;
                    case SDLK_DOWN:   c->bas = 0; break;
                    case SDLK_ESCAPE: c->echap = 0; break;
                    case SDLK_g:      c->echap = 0; break;
                    case SDLK_e:      c->e = 0; break;
                }
                break;
                
            case SDL_MOUSEBUTTONDOWN:
                if (event.button.button == SDL_BUTTON_LEFT) {
                    c->echap = 0;
                }
                break;
        }
    }
}

/*void recupererclavier(clavier *c, int *continuer)
{
    SDL_Event event;
    while(SDL_PollEvent(&event))
    {
        switch(event.type)
        {
            case SDL_QUIT:
                *continuer = 0;
                break;
                
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym)
                {
                    case SDLK_LEFT:   c->Gauche = 1; break;
                    case SDLK_RIGHT:  c->droite = 1; break;
                    case SDLK_UP:     c->haut = 1; break;
                    case SDLK_DOWN:   c->bas = 1; break;
                    case SDLK_ESCAPE: c->echap = 1; break;
                    case SDLK_g:      c->echap = 1; break;
                    case SDLK_e:      c->e = 0; break;*menuActif = 1; break; 
                }
                break;
                
            case SDL_KEYUP:
                switch(event.key.keysym.sym)
                {
                    case SDLK_LEFT:   c->Gauche = 0; break;
                    case SDLK_RIGHT:  c->droite = 0; break;
                    case SDLK_UP:     c->haut = 0; break;
                    case SDLK_DOWN:   c->bas = 0; break;
                    case SDLK_ESCAPE: c->echap = 0; break;
                    case SDLK_g:      c->echap = 0; break;
                    case SDLK_e:      c->e = 0; break;
                }
                break;
                
            case SDL_MOUSEBUTTONDOWN:
                if(event.button.button == SDL_BUTTON_LEFT)
                    c->echap = 0;
                break;
        }
    }
}*/
void scroll(Background *B, clavier *c)
{
    const int scroll_speed = 5;
    
    if(c->Gauche && B->cam.x > 0)
        B->cam.x -= scroll_speed;
    if(c->droite && B->cam.x < B->Bg_IMG->w - B->cam.w)
        B->cam.x += scroll_speed;
    if(c->haut && B->cam.y > 0)
        B->cam.y -= scroll_speed;
    if(c->bas && B->cam.y < B->Bg_IMG->h - B->cam.h)
        B->cam.y += scroll_speed;
}

void libererbackground(Background *B)
{
    if(B->Bg_IMG)
        SDL_FreeSurface(B->Bg_IMG);
    if(B->music)
        Mix_FreeMusic(B->music);
    for(int i = 0; i < 50; i++) {
        if(B->anim[i])
            SDL_FreeSurface(B->anim[i]);
    }
}

void initialiserTempsJeu(TempsJeu *tj)
{
    if(TTF_Init() == -1) {
        printf("Erreur d'initialisation de TTF_Init : %s\n", TTF_GetError());
        exit(EXIT_FAILURE);
    }
    
    tj->police = TTF_OpenFont("Minecraft.ttf", 24);
    if(!tj->police) {
        printf("Erreur chargement police : %s\n", TTF_GetError());
    }
    
    tj->couleur.r = 255;
    tj->couleur.g = 255;
    tj->couleur.b = 255;
    
    tj->position.x = 10;
    tj->position.y = 10;
    
    time(&tj->temps_debut);
    strcpy(tj->temps_ecoule, "00:00:00");
    
    tj->texte = TTF_RenderText_Blended(tj->police, tj->temps_ecoule, tj->couleur);
}

void mettreAJourTempsJeu(TempsJeu *tj)
{
    time_t maintenant;
    time(&maintenant);
    
    double secondes = difftime(maintenant, tj->temps_debut);
    
    int heures = (int)(secondes / 3600);
    int minutes = (int)((secondes - (heures * 3600)) / 60);
    int secs = (int)(secondes - (heures * 3600) - (minutes * 60));
    
    snprintf(tj->temps_ecoule, 20, "%02d:%02d:%02d", heures, minutes, secs);
    
    if(tj->texte) {
        SDL_FreeSurface(tj->texte);
    }
    tj->texte = TTF_RenderText_Blended(tj->police, tj->temps_ecoule, tj->couleur);
}

void afficherTempsJeu(TempsJeu *tj, SDL_Surface *ecran)
{
    if(tj->texte) {
        SDL_BlitSurface(tj->texte, NULL, ecran, &tj->position);
    }
}

void libererTempsJeu(TempsJeu *tj)
{
    if(tj->texte) {
        SDL_FreeSurface(tj->texte);
    }
    if(tj->police) {
        TTF_CloseFont(tj->police);
    }
    TTF_Quit();
}

void initGuideJeu(GuideJeu *guide) 
{
    guide->guide_img = IMG_Load("guid.png");
    if(!guide->guide_img) {
        printf("Erreur chargement image guide: %s\n", IMG_GetError());
        exit(EXIT_FAILURE);
    }

    guide->font = TTF_OpenFont("Minecraft.ttf", 24);
    if(!guide->font) {
        printf("Erreur chargement police: %s\n", TTF_GetError());
        exit(EXIT_FAILURE);
    }

    FILE *file = fopen("guide.txt", "r");
    if(file) {
        size_t len = fread(guide->text_content, 1, sizeof(guide->text_content)-1, file);
        guide->text_content[len] = '\0';
        fclose(file);
    } else {
        strcpy(guide->text_content, "Guide non disponible");
    }

    SDL_Color white = {255, 255, 255};
    guide->text_surface = render_multiline_text(guide->font, guide->text_content, white, guide->guide_img->w - 40);
    if(!guide->text_surface) {
        printf("Erreur création surface texte: %s\n", TTF_GetError());
    }

    guide->pos.x = (SCREEN_W - guide->guide_img->w) / 2;
    guide->pos.y = (SCREEN_H - guide->guide_img->h) / 2;
    guide->visible = 0;
}


SDL_Surface* render_multiline_text(TTF_Font *font, const char *text, SDL_Color color, int max_width) {
    SDL_Surface *result = NULL;
    char *copy = strdup(text);
    char *line = strtok(copy, "\n");
    
    while(line) {
        SDL_Surface *line_surface = TTF_RenderText_Blended(font, line, color);
        if(!line_surface) continue;
        
        if(!result) {
            result = line_surface;
        } else {
            SDL_Surface *temp = SDL_CreateRGBSurface(0, 
                MAX(result->w, line_surface->w),
                result->h + line_surface->h,
                32, 0, 0, 0, 0);
                
            SDL_BlitSurface(result, NULL, temp, NULL);
            SDL_Rect dest = {0, result->h};
            SDL_BlitSurface(line_surface, NULL, temp, &dest);
            
            SDL_FreeSurface(result);
            SDL_FreeSurface(line_surface);
            result = temp;
        }
        
        line = strtok(NULL, "\n");
    }
    
    free(copy);
    return result;
}


void afficherGuideJeu(GuideJeu *guide, SDL_Surface *ecran) 
{
    if(guide->visible) {
        SDL_BlitSurface(guide->guide_img, NULL, ecran, &guide->pos);
        
        SDL_Rect text_pos = {
            guide->pos.x + 20,
            guide->pos.y + 20,
            0, 0
        };
        SDL_BlitSurface(guide->text_surface, NULL, ecran, &text_pos);
    }
}

void libererGuideJeu(GuideJeu *guide) 
{
    if(guide->guide_img) SDL_FreeSurface(guide->guide_img);
    if(guide->text_surface) SDL_FreeSurface(guide->text_surface);
    if(guide->font) TTF_CloseFont(guide->font);
}

#include "scores.h"

void afficherScores() {
    // Créer une nouvelle fenêtre SDL pour afficher les scores
    SDL_Surface *nouvelleFenetre = SDL_SetVideoMode(400, 450, 32, SDL_HWSURFACE);
    if (!nouvelleFenetre) {
        fprintf(stderr, "Erreur lors de la création de la fenêtre des scores : %s\n", SDL_GetError());
        return;
    }

    // Charger l'image de fond
    SDL_Surface *background = IMG_Load("s_bakgd.png");
    if (!background) {
        fprintf(stderr, "Erreur lors du chargement de l'image de fond: %s\n", IMG_GetError());
        return;
    }

    // Initialiser SDL_ttf
    if (TTF_Init() == -1) {
        fprintf(stderr, "Erreur lors de l'initialisation de SDL_ttf: %s\n", TTF_GetError());
        SDL_FreeSurface(background);
        return;
    }

    TTF_Font *font = TTF_OpenFont("Arial.ttf", 24);
    if (!font) {
        fprintf(stderr, "Erreur lors du chargement de la police: %s\n", TTF_GetError());
        SDL_FreeSurface(background);
        TTF_Quit();
        return;
    }

    SDL_Color textColor = {255, 255, 255}; // Texte en blanc

    // Boucle principale pour afficher les scores
    int running = 1;
    SDL_Event event;
    
    while (running) {
        // Afficher l'image de fond
        SDL_BlitSurface(background, NULL, nouvelleFenetre, NULL);

        // Afficher le titre
        SDL_Surface *titleSurface = TTF_RenderText_Solid(font, "Meilleurs Scores", textColor);
        if (titleSurface) {
            SDL_Rect titlePos = {(nouvelleFenetre->w - titleSurface->w) / 2, 50, 0, 0};
            SDL_BlitSurface(titleSurface, NULL, nouvelleFenetre, &titlePos);
            SDL_FreeSurface(titleSurface);
        }

        // Lire et afficher les scores
        FILE *file = fopen("scores.txt", "r");
        if (file) {
            char line[100];
            int y = 150; // Position verticale pour afficher les scores

            while (fgets(line, sizeof(line), file)) {
                line[strcspn(line, "\n")] = 0; // Supprimer le saut de ligne

                SDL_Surface *scoreSurface = TTF_RenderText_Solid(font, line, textColor);
                if (scoreSurface) {
                    SDL_Rect scorePos = {(nouvelleFenetre->w - scoreSurface->w) / 2, y, 0, 0};
                    SDL_BlitSurface(scoreSurface, NULL, nouvelleFenetre, &scorePos);
                    SDL_FreeSurface(scoreSurface);
                }
                y += 30;
            }
            fclose(file);
        } else {
            fprintf(stderr, "Erreur lors de l'ouverture du fichier des scores.\n");
        }

        // Mettre à jour l'affichage
        SDL_Flip(nouvelleFenetre);

        // Gestion des événements
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = 0;
            } else if (event.type == SDL_KEYDOWN) {
                if (event.key.keysym.sym == SDLK_ESCAPE) {
                    running = 0; // Quitter avec Échap
                    exit(0);
                }
            }
        }
    }

    // Libérer les ressources
    SDL_FreeSurface(background);
    TTF_CloseFont(font);
    TTF_Quit();
}

void ajouterScore(char *nom) {
    // Ouvrir le fichier en mode lecture pour déterminer le dernier numéro de score
    FILE *file = fopen("scores.txt", "r");
    int i = 0; // Compteur de scores

    if (file) {
        char line[100];
        while (fgets(line, sizeof(line), file)) {
            // Incrémenter le compteur pour chaque ligne lue
            i++;
        }
        fclose(file);
    }

    // Ouvrir le fichier en mode ajout (append)
    file = fopen("scores.txt", "a");
    if (file == NULL) {
        fprintf(stderr, "Erreur lors de l'ouverture du fichier des scores.\n");
        return;
    }

    // Écrire le numéro du score et le nom dans le fichier
    fprintf(file, "%d. %s\n", i + 1, nom);

    // Fermer le fichier
    fclose(file);

    printf("Score ajouté pour : %s (Score n°%d)\n", nom, i + 1);
}
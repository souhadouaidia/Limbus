#ifndef SCORES_H
#define SCORES_H

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include <stdio.h>
#include <string.h>

void afficherScores();
void ajouterScore(char *nom);

#endif

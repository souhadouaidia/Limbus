#include "background.h"
#include "menuEnigme.h"

int main(int argc, char *argv[])
{
    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        printf("SDL n'a pas pu s'initialiser! SDL_Error: %s\n", SDL_GetError());
        return EXIT_FAILURE;
    }

    SDL_Surface *ecran = SDL_SetVideoMode(SCREEN_W, SCREEN_H, 32, SDL_SWSURFACE);
    if(!ecran) {
        printf("La fenêtre n'a pas pu être créée! SDL_Error: %s\n", SDL_GetError());
        SDL_Quit();
        return EXIT_FAILURE;
    }

    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        printf("SDL_mixer n'a pas pu s'initialiser! Mix_Error: %s\n", Mix_GetError());
    }

    SDL_WM_SetCaption("Background", NULL);

    Background B;
    initbackground(&B);

    clavier c = {0};
    int continuer = 1;
    int menuActif = 0;        // Nouvelle variable pour gérer l'état du menu
    int saisieActive = 0;     // Nouvelle variable pour gérer la saisie de texte
    char texteSaisi[100] = ""; // Buffer pour stocker le texte saisi

    TempsJeu tj;
    initialiserTempsJeu(&tj);

    GuideJeu guide;
    initGuideJeu(&guide);

    
    while(continuer)
    {
        // Modification ici pour passer menuActif en paramètre
        //recupererclavier(&c, &continuer);  // Remove &menuActif
        recupererClavier(ecran,&c, &continuer, &menuActif, texteSaisi, sizeof(texteSaisi));
        if(c.echap) {
            guide.visible = !guide.visible;
            c.echap = 0;
        }

        // Gestion spécifique du menu
        if(menuActif) {
            SDL_EnableUNICODE(1); // Active la saisie de texte
            saisieActive = 1;
            
            // Gérer les événements spécifiques au menu
            SDL_Event event;
            while(SDL_PollEvent(&event)) {
                if(event.type == SDL_KEYDOWN) {
                    if(event.key.keysym.sym == SDLK_RETURN) {
                        // Valider la saisie
                        menuActif = 0;
                        saisieActive = 0;
                        printf("Nom saisi: %s\n", texteSaisi);
                    } else if(event.key.keysym.sym == SDLK_BACKSPACE) {
                        // Gérer le retour arrière
                        int len = strlen(texteSaisi);
                        if(len > 0) texteSaisi[len-1] = '\0';
                    } else if(event.key.keysym.sym == SDLK_ESCAPE) {
                        // Quitter le menu
                        menuActif = 0;
                        saisieActive = 0;
                    }
                
                }/*else if(event.type == SDL_TEXTINPUT && saisieActive) {
                    // Gérer la saisie de texte
                    if(strlen(texteSaisi) < 99) {
                        strcat(texteSaisi, event.text.text);
                    }
                }*/
                else if (event.type == SDL_KEYDOWN && saisieActive) 
                {
                    // Handle backspace
                    if (event.key.keysym.sym == SDLK_BACKSPACE) 
                    {
                        int len = strlen(texteSaisi);
                        if (len > 0) texteSaisi[len-1] = '\0';
                    }
                    // Handle normal text input (ASCII only)
                    else if (event.key.keysym.unicode >= 32 && event.key.keysym.unicode < 128) 
                    {
                        int len = strlen(texteSaisi);
                        if (len < 99) 
                        {
                            texteSaisi[len] = (char)event.key.keysym.unicode;
                            texteSaisi[len+1] = '\0';
                        }
                    }
                }

            }
        } else {
            SDL_EnableUNICODE(0); // Désactive la saisie de texte
            scroll(&B, &c);
        }

        mettreAJourTempsJeu(&tj);

        SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 0, 0, 0));
        
        afficherbackground(&B, ecran);
        afficherTempsJeu(&tj, ecran);
        afficherGuideJeu(&guide, ecran);
        
        // Afficher le menu si actif
        if(menuActif) {
            afficherMenu(ecran, texteSaisi, &continuer, &saisieActive);
        }

        static int prev_echap = 0;
        if(c.echap && !prev_echap) {
            guide.visible = !guide.visible;
        }
        prev_echap = c.echap;
        
        SDL_Flip(ecran);

        SDL_Delay(1000/FPS);
    }

    libererbackground(&B);
    libererTempsJeu(&tj);
    libererGuideJeu(&guide);

    Mix_CloseAudio();
    SDL_Quit();

    return EXIT_SUCCESS;
}
#ifndef BACKGROUND_H
#define BACKGROUND_H

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <vorbis/vorbisfile.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "scores.h"

#define SCREEN_W 800
#define SCREEN_H 600
#define FPS 60

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

typedef struct
{
    SDL_Surface *Bg_IMG;
    SDL_Rect Pos;
    SDL_Rect cam;
    Mix_Music *music;
    SDL_Surface *anim[50];
    int frame;
    SDL_Rect Posanim;
} Background;

typedef struct
{
    int Gauche, droite, haut, bas,echap, e;
} clavier;

typedef struct 
{
    time_t temps_debut;
    char temps_ecoule[20];
    SDL_Surface *texte;
    SDL_Rect position;
    TTF_Font *police;
    SDL_Color couleur;
} TempsJeu;

typedef struct {
    SDL_Surface *guide_img;
    SDL_Surface *text_surface;
    SDL_Rect pos;
    TTF_Font *font;
    int visible;
    char text_content[1024];
} GuideJeu;

void initbackground(Background *B);
void afficherbackground(Background *B, SDL_Surface *ecran);
void animerbackground(Background *B, SDL_Surface *ecran);
//void recupererclavier(clavier *c, int *continuer);
void recupererClavier(SDL_Surface *ecran,clavier *c, int *continuer, int *menuActif, char *texte, int tailleTexte);
void scroll(Background *B, clavier *c);
void libererbackground(Background *B);

void initialiserTempsJeu(TempsJeu *tj);
void mettreAJourTempsJeu(TempsJeu *tj);
void afficherTempsJeu(TempsJeu *tj, SDL_Surface *ecran);
void libererTempsJeu(TempsJeu *tj);

void initGuideJeu(GuideJeu *guide);
void afficherGuideJeu(GuideJeu *guide, SDL_Surface *ecran);
void libererGuideJeu(GuideJeu *guide);

static SDL_Surface* render_multiline_text(TTF_Font *font, const char *text, SDL_Color color, int max_width);
void gererMenuValidation(SDL_Surface *ecran, char *nomJoueur);

#endif

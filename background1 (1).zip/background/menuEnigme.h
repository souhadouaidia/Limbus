#ifndef MENU_ENIGME_H
#define MENU_ENIGME_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <string.h>
#include <SDL/SDL_mixer.h>

#define SCREEN_W 800
#define SCREEN_H 600

// Déclaration des fonctions
void afficherMenu(SDL_Surface *ecran, char *texteSaisi, int *quitter, int *saisieActive);
void gererEvenements(SDL_Event event, int *quitter, char *texteSaisi, int *saisieActive, int *afficherScoresFlag, SDL_Surface *ecran, Mix_Chunk *clicSound);
void afficherScores(); // Ajoutez cette ligne

#endif

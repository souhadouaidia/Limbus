// ennemi.h
#ifndef ENNEMI_H
#define ENNEMI_H

#include <SDL/SDL.h>

// Enemy structure
typedef struct {
    int x, y, w, h;  // Position and size
    int dy;           // Movement speed (up/down)
    int health;       // Enemy health
    int frame;        // Animation frame index
    SDL_Surface* sprites[8];  // 8 frames for the enemy (4 up, 4 down)
} Enemy;

// Function declarations
void moveEnemy(Enemy* enemy);
void drawEnemy(SDL_Surface* screen, Enemy* enemy);

#endif // ENNEMI_H


// ennemi.c
#include "ennemi.h"

// Move enemy up and down
void moveEnemy(Enemy* enemy) {
    if (enemy->dy > 0) {  // Moving down
        enemy->y += enemy->dy;
        if (enemy->y + enemy->h > 480) {  // If enemy goes beyond screen height
            enemy->dy = -enemy->dy;  // Move it up
        }
    } else {  // Moving up
        enemy->y += enemy->dy;
        if (enemy->y < 0) {  // If enemy goes above screen
            enemy->dy = -enemy->dy;  // Move it down
        }
    }
    // Change animation frame
    enemy->frame = (enemy->frame + 1) % 4 + (enemy->dy > 0 ? 0 : 4);
}

// Draw the enemy and health bar
void drawEnemy(SDL_Surface* screen, Enemy* enemy) {
    if (enemy->health > 0) {
        // Draw enemy
        SDL_Rect destRect = { enemy->x, enemy->y, enemy->w, enemy->h };
        SDL_BlitSurface(enemy->sprites[enemy->frame], NULL, screen, &destRect);

        // Draw health bar above enemy
        SDL_Rect healthBar = { enemy->x, enemy->y - 10, enemy->w, 5 };
        SDL_FillRect(screen, &healthBar, SDL_MapRGB(screen->format, 255, 0, 0));

        healthBar.w = (int)((float)enemy->health / 100 * enemy->w);  // Scale health bar width
        SDL_FillRect(screen, &healthBar, SDL_MapRGB(screen->format, 0, 255, 0));  // Green health bar
    }
}


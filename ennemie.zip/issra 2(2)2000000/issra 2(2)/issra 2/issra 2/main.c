// main.c
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include "ennemi.h"

// Function to initialize SDL
int initSDL();

// Function to check for rectangle collision
int checkRectCollision(SDL_Rect rect1, SDL_Rect rect2) {
    return rect1.x < rect2.x + rect2.w &&
           rect1.x + rect1.w > rect2.x &&
           rect1.y < rect2.y + rect2.h &&
           rect1.y + rect1.h > rect2.y;
}

// Function to check if a position is colliding with the white areas (impassable)
int isCollidingWithWhiteArea(SDL_Surface* collisionMap, int x, int y) {
    Uint32 pixelColor = *((Uint32*)collisionMap->pixels + (y * collisionMap->w + x));
    Uint8 r, g, b;
    SDL_GetRGB(pixelColor, collisionMap->format, &r, &g, &b);

    // Check if the pixel is white (255, 255, 255)
    return (r == 255 && g == 255 && b == 255);
}

int main(int argc, char* argv[]) {
    if (!initSDL()) return 1;

    SDL_Surface* screen = SDL_GetVideoSurface();

    // Load the map as background
    SDL_Surface* map = IMG_Load("map3.jpg");
    if (map == NULL) {
        printf("Error loading map image: %s\n", SDL_GetError());
        return 1;
    }

    // Load collision map
    SDL_Surface* collisionMap = IMG_Load("map3collision.jpg");
    if (collisionMap == NULL) {
        printf("Error loading collision map image: %s\n", SDL_GetError());
        return 1;
    }

    // Load enemy sprite frames
    Enemy enemy;
    enemy.sprites[0] = IMG_Load("ennemi_down1.png");
    enemy.sprites[1] = IMG_Load("ennemi_down2.png");
    enemy.sprites[2] = IMG_Load("ennemi_down3.png");
    enemy.sprites[3] = IMG_Load("ennemi_down4.png");
    enemy.sprites[4] = IMG_Load("ennemi_up1.png");
    enemy.sprites[5] = IMG_Load("ennemi_up2.png");
    enemy.sprites[6] = IMG_Load("ennemi_up3.png");
    enemy.sprites[7] = IMG_Load("ennemi_up4.png");

    // Initialize enemy position, movement direction, and health
    enemy.x = 400;
    enemy.y = 300;
    enemy.w = 50;
    enemy.h = 50;
    enemy.dy = 2;  // Moving down initially
    enemy.frame = 0;
    enemy.health = 100;

    SDL_Rect player = { 100, 100, 50, 50 };  // Start at position (100, 100), 50x50 square

    // Camera rectangle
    SDL_Rect camera = {0, 0, 640, 480};  // Camera view size is 640x480, same as the screen size

    SDL_Event event;
    int quit = 0;

    // Main game loop
    while (!quit) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                quit = 1;
            }
        }

        // Get key states
        const Uint8* keys = SDL_GetKeyState(NULL);

        // Move player with bounds and collision checking
        if (keys[SDLK_UP]) {
            // Check if the new position is within bounds and not colliding with white areas
            if (player.y > 0 && !isCollidingWithWhiteArea(collisionMap, player.x + player.w / 2, player.y - 1)) {
                player.y -= 2;
            }
        }
        if (keys[SDLK_DOWN]) {
            if (player.y < map->h - player.h && !isCollidingWithWhiteArea(collisionMap, player.x + player.w / 2, player.y + player.h + 1)) {
                player.y += 2;
            }
        }
        if (keys[SDLK_LEFT]) {
            if (player.x > 0 && !isCollidingWithWhiteArea(collisionMap, player.x - 1, player.y + player.h / 2)) {
                player.x -= 2;
            }
        }
        if (keys[SDLK_RIGHT]) {
            if (player.x < map->w - player.w && !isCollidingWithWhiteArea(collisionMap, player.x + player.w + 1, player.y + player.h / 2)) {
                player.x += 2;
            }
        }

        // Check for collision with the enemy
        SDL_Rect playerRect = { player.x, player.y, player.w, player.h };
        SDL_Rect enemyRect = { enemy.x, enemy.y, enemy.w, enemy.h };

        if (checkRectCollision(playerRect, enemyRect)) {
            // Decrease health when player collides with the enemy
            enemy.health -= 10;
            if (enemy.health <= 0) {
                enemy.health = 0;
                enemy.x = -enemy.w;  // Move the enemy off-screen
            }
        }

        // Move enemy (up and down)
        moveEnemy(&enemy);

        // Camera follows the player
        camera.x = player.x - camera.w / 2;
        camera.y = player.y - camera.h / 2;

        // Prevent camera from going outside the map bounds
        if (camera.x < 0) camera.x = 0;
        if (camera.y < 0) camera.y = 0;
        if (camera.x > map->w - camera.w) camera.x = map->w - camera.w;
        if (camera.y > map->h - camera.h) camera.y = map->h - camera.h;

        // Fill the screen with black
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));

        // Draw the map (background) with camera offset
        SDL_Rect mapRect = { -camera.x, -camera.y, 640, 480 };  // Adjust map position based on camera
        SDL_BlitSurface(map, NULL, screen, &mapRect);

        // Draw player as a blue square
        SDL_FillRect(screen, &player, SDL_MapRGB(screen->format, 0, 0, 255));

        // Draw enemy with animation and health bar
        drawEnemy(screen, &enemy);

        // Update the screen
        SDL_Flip(screen);

        // Delay to control frame rate
        SDL_Delay(16);  // ~60 FPS
    }

    // Free resources
    for (int i = 0; i < 8; i++) {
        SDL_FreeSurface(enemy.sprites[i]);
    }
    SDL_FreeSurface(map);  // Free map surface
    SDL_FreeSurface(collisionMap);  // Free collision map surface

    // Clean up and quit
    SDL_Quit();

    return 0;
}

// Function to initialize the SDL environment
int initSDL() {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL initialization failed: %s\n", SDL_GetError());
        return 0;
    }

    // Set the video mode (screen size: 640x480)
    if (SDL_SetVideoMode(640, 480, 32, SDL_SWSURFACE) == NULL) {
        printf("Failed to set video mode: %s\n", SDL_GetError());
        return 0;
    }

    return 1;
}


#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <stdio.h>

#define SCREEN_WIDTH 1280
#define SCREEN_HEIGHT 720

typedef struct {
    SDL_Surface *normal;
    SDL_Surface *hover;
    SDL_Rect position;
    int isHovered;
} Button;

SDL_Surface *screen = NULL;
SDL_Surface *background2 = NULL, *background3 = NULL;
Mix_Music *music = NULL;
Mix_Chunk *clickSound = NULL;
int currentScreen = 2;

Button mono, multi, retour, avatar1, avatar2, input1, input2, valider, retour2;

void initButton(Button *btn, const char *normalImg, const char *hoverImg, int x, int y) {
    btn->normal = IMG_Load(normalImg);
    btn->hover = IMG_Load(hoverImg);
    if (!btn->normal || !btn->hover) {
        printf("Erreur chargement bouton %s ou %s: %s\n", normalImg, hoverImg, IMG_GetError());
    }
    btn->position.x = x;
    btn->position.y = y;
    btn->isHovered = 0;
}

void drawButton(Button *btn) {
    SDL_BlitSurface(btn->isHovered ? btn->hover : btn->normal, NULL, screen, &btn->position);
}

void handleButtonHover(Button *btn, int mouseX, int mouseY) {
    btn->isHovered = (mouseX >= btn->position.x && mouseX <= btn->position.x + btn->normal->w &&
                      mouseY >= btn->position.y && mouseY <= btn->position.y + btn->normal->h);
}

void init() {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 32, SDL_SWSURFACE);
    SDL_WM_SetCaption("SDL Menu", NULL);
    
    background2 = IMG_Load("arriereplan2.jpg");
    background3 = IMG_Load("arriereplan3.jpg");
    
    if (!background2 || !background3) {
        printf("Erreur chargement des images de fond: %s\n", IMG_GetError());
    }
    
    Mix_OpenAudio(22050, MIX_DEFAULT_FORMAT, 2, 4096);
    music = Mix_LoadMUS("music.mp3");
    clickSound = Mix_LoadWAV("click.wav");
    
    initButton(&mono, "mono.png", "mono_hover.png", 400, 250);
    initButton(&multi, "multi.png", "multi_hover.png", 700, 250);
    initButton(&retour, "retour.png", "retour_hover.png", 1050, 600);
    
    initButton(&avatar1, "avatar1.png", "avatar1_hover.png", 400, 200);
    initButton(&avatar2, "avatar2.png", "avatar2_hover.png", 700, 200);
    initButton(&input1, "input1.png", "input1_hover.png", 400, 300);
    initButton(&input2, "input2.png", "input2_hover.png", 700, 300);
    initButton(&valider, "valider.png", "valider_hover.png", 550, 400);
    initButton(&retour2, "retour.png", "retour_hover.png", 1050, 600);
    
    if (music) Mix_PlayMusic(music, -1);
}

void cleanup() {
    SDL_FreeSurface(background2);
    SDL_FreeSurface(background3);
    Mix_FreeMusic(music);
    Mix_FreeChunk(clickSound);
    SDL_Quit();
}

void gameLoop() {
    int running = 1;
    SDL_Event event;
    
    while (running) {
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
        
        if (currentScreen == 2) {
            SDL_BlitSurface(background2, NULL, screen, NULL);
            drawButton(&mono);
            drawButton(&multi);
            drawButton(&retour);
        } else if (currentScreen == 3) {
            SDL_BlitSurface(background3, NULL, screen, NULL);
            drawButton(&avatar1);
            drawButton(&avatar2);
            drawButton(&input1);
            drawButton(&input2);
            drawButton(&valider);
            drawButton(&retour2);
        }
        
        SDL_Flip(screen);
        
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    running = 0;
                    break;
                case SDL_MOUSEMOTION:
                    if (currentScreen == 2) {
                        handleButtonHover(&mono, event.motion.x, event.motion.y);
                        handleButtonHover(&multi, event.motion.x, event.motion.y);
                        handleButtonHover(&retour, event.motion.x, event.motion.y);
                    } else if (currentScreen == 3) {
                        handleButtonHover(&avatar1, event.motion.x, event.motion.y);
                        handleButtonHover(&avatar2, event.motion.x, event.motion.y);
                        handleButtonHover(&input1, event.motion.x, event.motion.y);
                        handleButtonHover(&input2, event.motion.x, event.motion.y);
                        handleButtonHover(&valider, event.motion.x, event.motion.y);
                        handleButtonHover(&retour2, event.motion.x, event.motion.y);
                    }
                    break;
                case SDL_MOUSEBUTTONDOWN:
                    if (clickSound) Mix_PlayChannel(-1, clickSound, 0);
                    
                    if (currentScreen == 2) {
                        if (mono.isHovered) {
                            printf("Mode solo sélectionné\n");
                            currentScreen = 3;
                        } else if (multi.isHovered) {
                            printf("Mode multijoueur sélectionné\n");
                            currentScreen = 3;
                        } else if (retour.isHovered) {
                            running = 0;
                        }
                    } else if (currentScreen == 3) {
                        if (avatar1.isHovered) {
                            printf("Avatar 1 sélectionné\n");
                        } else if (avatar2.isHovered) {
                            printf("Avatar 2 sélectionné\n");
                        } else if (input1.isHovered) {
                            printf("Input 1 sélectionné\n");
                        } else if (input2.isHovered) {
                            printf("Input 2 sélectionné\n");
                        } else if (valider.isHovered) {
                            printf("Entrée dans le sous-menu Meilleurs scores\n");
                            currentScreen = 4;
                        } else if (retour2.isHovered) {
                            currentScreen = 2;
                        }
                    }
                    break;
                case SDL_KEYDOWN:
                    if (event.key.keysym.sym == SDLK_ESCAPE) {
                        running = 0;  
                    } else if (currentScreen == 3 && event.key.keysym.sym == SDLK_RETURN) {
                        if (clickSound) Mix_PlayChannel(-1, clickSound, 0);
                        printf("Entrée dans le sous-menu Meilleurs scores\n");
                        currentScreen = 4;
                    }
                    break;
            }
        }
    }
}

int main() {
    init();
    gameLoop();
    cleanup();
    return 0;
}


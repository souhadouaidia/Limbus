#include "header.h"

int main(int argc, char *argv[]) {
    SDL_Surface *screen, *background;
    SDL_Event event;
    int running = 1;

    // Initialisation
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    SDL_WM_SetCaption("Menu Principal", NULL);
    screen = SDL_SetVideoMode(1300, 800, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    if (screen == NULL) {
        fprintf(stderr, "Erreur : %s\n", SDL_GetError());
        return 1;
    }

    background = IMG_Load("background.png");

    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);
    Mix_Music *music = Mix_LoadMUS("musique.mp3");
    Mix_Chunk *hoverSound = Mix_LoadWAV("sound.wav");
    Mix_PlayMusic(music, -1);

    Button jouer, options, scores, histoire, quitter;
    initButton(&jouer, 500, 230, "jouer.png", "jouer_hover.png");
    initButton(&options, 500, 330, "options.png", "options_hover.png");
    initButton(&scores, 500, 430, "meilleurs_scores.png", "meilleurs_scores_hover.png");
    initButton(&histoire, 500, 530, "histoire.png", "histoire_hover.png");
    initButton(&quitter, 500, 630, "quitter.png", "quitter_hover.png");

    while (running) {
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    running = 0;
                    break;
                case SDL_MOUSEMOTION: {
                    int x = event.motion.x, y = event.motion.y;
                    Button *buttons[] = {&jouer, &options, &scores, &histoire, &quitter};
                    for (int i = 0; i < 5; i++) {
                        if (x >= buttons[i]->position.x && x <= buttons[i]->position.x + BUTTON_WIDTH &&
                            y >= buttons[i]->position.y && y <= buttons[i]->position.y + BUTTON_HEIGHT) {
                            if (!buttons[i]->hovered) {
                                Mix_PlayChannel(-1, hoverSound, 0);
                                buttons[i]->hovered = 1;
                            }
                        } else {
                            buttons[i]->hovered = 0;
                        }
                    }
                } break;

                case SDL_MOUSEBUTTONDOWN: {
                    int x = event.button.x, y = event.button.y;
                    if (x >= quitter.position.x && x <= quitter.position.x + BUTTON_WIDTH &&
                        y >= quitter.position.y && y <= quitter.position.y + BUTTON_HEIGHT) {
                        running = 0;
                    }
                } break;

                case SDL_KEYDOWN:
                    switch (event.key.keysym.sym) {
                        case SDLK_j: printf("Jouer sélectionné !\n"); break;
                        case SDLK_o: printf("Options sélectionné !\n"); break;
                        case SDLK_m: printf("Meilleurs Scores sélectionné !\n"); break;
                        case SDLK_ESCAPE: running = 0; break;
                    }
                    break;
            }
        }

        SDL_BlitSurface(background, NULL, screen, NULL);
        renderButton(screen, &jouer);
        renderButton(screen, &options);
        renderButton(screen, &scores);
        renderButton(screen, &histoire);
        renderButton(screen, &quitter);
        SDL_Flip(screen);
    }

    // Libération
    SDL_FreeSurface(background);
    SDL_FreeSurface(jouer.image); SDL_FreeSurface(jouer.hover_image);
    SDL_FreeSurface(options.image); SDL_FreeSurface(options.hover_image);
    SDL_FreeSurface(scores.image); SDL_FreeSurface(scores.hover_image);
    SDL_FreeSurface(histoire.image); SDL_FreeSurface(histoire.hover_image);
    SDL_FreeSurface(quitter.image); SDL_FreeSurface(quitter.hover_image);
    Mix_FreeMusic(music);
    Mix_FreeChunk(hoverSound);
    Mix_CloseAudio();
    SDL_Quit();

    return 0;
}


#ifndef HEADER_H
#define HEADER_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>

#define BUTTON_WIDTH 283
#define BUTTON_HEIGHT 85

// Structure pour un bouton
typedef struct {
    SDL_Rect position;
    SDL_Surface *image;
    SDL_Surface *hover_image;
    int hovered;
} Button;

// Fonctions
void initButton(Button *button, int x, int y, const char *imagePath, const char *hoverPath);
void renderButton(SDL_Surface *screen, Button *button);

#endif


#include "header.h"

void initButton(Button *button, int x, int y, const char *imagePath, const char *hoverPath) {
    button->position.x = x;
    button->position.y = y;
    button->image = IMG_Load(imagePath);
    button->hover_image = IMG_Load(hoverPath);
    button->hovered = 0;
}

void renderButton(SDL_Surface *screen, Button *button) {
    SDL_BlitSurface(button->hovered ? button->hover_image : button->image, NULL, screen, &button->position);
}


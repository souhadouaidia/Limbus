#include "minimap.h"
int main()
{
    int boucle = 1;
    int vitesse = 10;
    int niveau = 1;
    int fin_niveau1 = 0;

    SDL_Surface *screen;
    SDL_Event event;
    minimap m;

    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        fprintf(stderr, "Erreur SDL : %s\n", SDL_GetError());
        return 1;
    }

    TTF_Init();
    srand(time(NULL));

    screen = SDL_SetVideoMode(1400, 800, 32, SDL_HWSURFACE | SDL_SRCALPHA);
    if (!screen) {
        fprintf(stderr, "Erreur vidéo : %s\n", SDL_GetError());
        return 1;
    }

    InitMinimap(&m);

    SDL_Surface *img_p = IMG_Load("perso1.png");
    if (!img_p) {
        fprintf(stderr, "Erreur perso1.png : %s\n", IMG_GetError());
        return 1;
    }

    SDL_Rect pos_p = {50, 600, img_p->w, img_p->h};

    SDL_Surface *img = IMG_Load("background.png");
    if (!img) {
        fprintf(stderr, "Erreur background.png : %s\n", IMG_GetError());
        return 1;
    }

    SDL_Rect pos = {0, 0};

    SDL_Surface *masque = SDL_LoadBMP("background.bmp");
    if (!masque) {
        fprintf(stderr, "Erreur background.bmp : %s\n", SDL_GetError());
        return 1;
    }

    SDL_Surface *img_ennemi = IMG_Load("ennemi1.png");
    if (!img_ennemi) {
        fprintf(stderr, "Erreur ennemi1.png : %s\n", IMG_GetError());
        return 1;
    }

    SDL_Surface *image_fin_niv1 = IMG_Load("fin_niveau1.jpg");
    if (!image_fin_niv1) {
        fprintf(stderr, "Erreur fin_niveau1.jpg : %s\n", IMG_GetError());
        return 1;
    }

    // Initialisation de l'ennemi
    Ennemi ennemi;
    ennemi.image = img_ennemi;
    ennemi.rect = (SDL_Rect){600, 500, img_ennemi->w, img_ennemi->h};
    ennemi.vitesse = 2;
    ennemi.direction = 1; // 1 pour la direction droite

    while (boucle)
    {
        //fin de niveau 1
        if (niveau == 1 && pos_p.x + pos_p.w >= img->w - 10) {
            fin_niveau1 = 1;
        }

        if (fin_niveau1) {
            SDL_BlitSurface(image_fin_niv1, NULL, screen, NULL);
            SDL_Flip(screen);

            SDL_Event e;
            while (1) {
                SDL_WaitEvent(&e);
                if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_n) {
                    niveau = 2;
                    fin_niveau1 = 0;

                    // Charger niveau 2
                    SDL_FreeSurface(img);
                    SDL_FreeSurface(masque);
                    img = IMG_Load("background2.jpg");
                    masque = SDL_LoadBMP("background2.bmp");

                    if (!img || !masque) {
                        fprintf(stderr, "Erreur chargement niveau 2.\n");
                        return 1;
                    }
                    SDL_Surface *formattedMasque = SDL_DisplayFormat(masque);
                    SDL_FreeSurface(masque);
                    masque = formattedMasque;
                    // k nestaamlou loadbmp tnjm tkounf format pixel dif ala pixel taa ecran donc ynjm affichage ywali ralenti atheka alech estaamlna displayformat pour le creer avec le meme contenu

                    // Repositionner le perso f awel niv
                    pos_p.x = 50;
                    pos_p.y = 600;
                    m.pos2_perso.x = pos_p.x;
                    m.pos2_perso.y = pos_p.y;
                    m.pos2_perso.w = 1100;  // Largeur du background2
                    m.pos2_perso.h = 733;   // Hauteur du background2

                    // mise à jour de l’image de la minimap 
                    SDL_Rect taille_minimap2 = {0, 0, 1100, 733}; // correspond à background2
                    ChangerMinimapNiveau(&m, "mini2.jpg", taille_minimap2);

                    break;
                }
            }
            continue;
        }

        // Déplacement de l'ennemi
        deplacerEnnemi(&ennemi, 0, img->w);
        m.pos2_ennemi.x = ennemi.rect.x;
        m.pos2_ennemi.y = ennemi.rect.y;


        // Affichage des éléments : fond mini perso ennemi
        SDL_BlitSurface(img, NULL, screen, &pos);
        AfficheMinimap(screen, m);
        SDL_BlitSurface(img_p, NULL, screen, &pos_p);
        afficherEnnemi(&ennemi, screen); // Affichage de l'ennemi
        SDL_Flip(screen);

        //  fermeture de fenetre= quitter le jeu
        if (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                boucle = 0;
            }
        }

        const Uint8 *keystates = SDL_GetKeyState(NULL);
        SDL_Rect temp = pos_p;
        // stock les touches du clavier dans un tab

        // Déplacement du joueur
        if (keystates[SDLK_RIGHT]) {
            temp.x = pos_p.x + vitesse;
            if (!collisionPP(temp, masque) && !Collision_AABB(temp, ennemi.rect)) {
                pos_p.x += vitesse;
                m.pos2_perso.x = pos_p.x;
            } else if (Collision_AABB(temp, ennemi.rect)) {
                pos_p.x -= 2 * vitesse;
            }
        }

        if (keystates[SDLK_LEFT]) {
            temp.x = pos_p.x - vitesse;
            if (!collisionPP(temp, masque) && !Collision_AABB(temp, ennemi.rect)) {
                pos_p.x -= vitesse;
                m.pos2_perso.x = pos_p.x;
            } else if (Collision_AABB(temp, ennemi.rect)) {
                pos_p.x += 2 * vitesse;
            }
        }

        if (keystates[SDLK_UP]) {
            temp.y = pos_p.y - vitesse;
            if (!collisionPP(temp, masque) && !Collision_AABB(temp, ennemi.rect)) {
                pos_p.y -= vitesse;
                m.pos2_perso.y = pos_p.y;
            } else if (Collision_AABB(temp, ennemi.rect)) {
                pos_p.y += 2 * vitesse;
            }
        }

        if (keystates[SDLK_DOWN]) {
            temp.y = pos_p.y + vitesse;
            if (!collisionPP(temp, masque) && !Collision_AABB(temp, ennemi.rect)) {
                pos_p.y += vitesse;
                m.pos2_perso.y = pos_p.y;
            } else if (Collision_AABB(temp, ennemi.rect)) {
                pos_p.y -= 2 * vitesse;
            }
        }

        // Mise à jour de la minimap
        annimer_MiniMap(&m);
        SDL_Delay(16); //pause de 16ms
    }

    // Libération des surfaces
    SDL_FreeSurface(img);
    SDL_FreeSurface(img_p);
    SDL_FreeSurface(m.img);
    SDL_FreeSurface(m.image_perso);
    SDL_FreeSurface(masque);
    SDL_FreeSurface(img_ennemi);
    SDL_FreeSurface(image_fin_niv1);

    TTF_Quit();
    SDL_Quit();

    return 0;
}

#include "minimap.h"

void InitMinimap(minimap *m)
{
    m->img = IMG_Load("mini.png"); // Image de la minimap
    m->pos.x = 0;
    m->pos.y = 0;
    m->pos.h = m->img->h;
    m->pos.w = m->img->w;

    m->image_perso = IMG_Load("perso.png"); // Icône représentant le joueur
    m->pos_perso.x = 0; // pod de perso sur mini
    m->pos_perso.y = 0;
    
    m->image_ennemi_minimap = IMG_Load("ennemi.png");

    initialiser_textTemps(&m->time);

    // position de joueur dans background
    m->pos2_perso.x = 500;
    m->pos2_perso.y = 500;
    m->pos2_perso.w = 1100;  // Largeur de background pour le rapport entre bg et mini
    m->pos2_perso.h = 733;   // Hauteur de background
}

void AfficheMinimap(SDL_Surface *screen, minimap m)
{
    SDL_BlitSurface(m.img, NULL, screen, &m.pos); // affi mini
    SDL_BlitSurface(m.image_perso, NULL, screen, &m.pos_perso);// affi de perso sur mini
    SDL_BlitSurface(m.time.txt, NULL, screen, &m.time.pos); // aff txt
    SDL_BlitSurface(m.image_ennemi_minimap, NULL, screen, &m.pos_ennemi); // affi ennemi
}

void initialiser_textTemps(text *t)
{
    t->color.r = 255; // 255 :blanc 
    t->color.g = 255;
    t->color.b = 255;
    t->police = TTF_OpenFont("police/Ubuntu-Bold.ttf", 40);
    strcpy(t->ch, "00:00:00"); // initialise le tmp a 0
    t->txt = TTF_RenderText_Blended(t->police, t->ch, t->color); // surface pour le txt
    t->pos.x = 1200;
    t->pos.y = 0;
}

void annimer_MiniMap(minimap *m)
{
    int time_sec = SDL_GetTicks() / 1000; // getTicks en milliseconde /1000 bech ywali en s 
    int heure = time_sec / 3600;
    int minute = (time_sec / 60) % 60; // 60% bech to9eed min et sec entre 0 et 59
    int seconde = time_sec % 60;

    sprintf(m->time.ch, "%02d:%02d:%02d", heure, minute, seconde);

    SDL_FreeSurface(m->time.txt);
    m->time.txt = TTF_RenderText_Blended(m->time.police, m->time.ch, m->time.color);
    // mise a jour du nv txt

    // Mise à jour position joueur sur la minimap
    int px = (m->pos2_perso.x * 100) / m->pos2_perso.w; // taille de perso dand bg en %
    int py = (m->pos2_perso.y * 100) / m->pos2_perso.h;

    m->pos_perso.x = (px * m->pos.w) / 100 + m->pos.x; // transforme % en pos sur mini
    m->pos_perso.y = (py * m->pos.h) / 100 + m->pos.y;
    // Empêcher le joueur de sortir de la minimap
    if (m->pos_perso.x < m->pos.x)
	m->pos_perso.x = m->pos.x;
    if (m->pos_perso.y < m->pos.y)
	m->pos_perso.y = m->pos.y;

    if (m->pos_perso.x > m->pos.x + m->pos.w - m->image_perso->w)
	m->pos_perso.x = m->pos.x + m->pos.w - m->image_perso->w;

    if (m->pos_perso.y > m->pos.y + m->pos.h - m->image_perso->h)
	m->pos_perso.y = m->pos.y + m->pos.h - m->image_perso->h;

    
    int ex = (m->pos2_ennemi.x * 100) / m->pos2_perso.w;
    int ey = (m->pos2_ennemi.y * 100) / m->pos2_perso.h;

    m->pos_ennemi.x = (ex * m->pos.w) / 100 + m->pos.x;
    m->pos_ennemi.y = (ey * m->pos.h) / 100 + m->pos.y;
    // empeche l'ennemi
    if (m->pos_ennemi.x < m->pos.x)
	m->pos_ennemi.x = m->pos.x;
    if (m->pos_ennemi.y < m->pos.y)
	m->pos_ennemi.y = m->pos.y;

    if (m->pos_ennemi.x > m->pos.x + m->pos.w - m->image_ennemi_minimap->w)
	m->pos_ennemi.x = m->pos.x + m->pos.w - m->image_ennemi_minimap->w;

    if (m->pos_ennemi.y > m->pos.y + m->pos.h - m->image_ennemi_minimap->h)
	m->pos_ennemi.y = m->pos.y + m->pos.h - m->image_ennemi_minimap->h;
}

SDL_Color GetPixel(SDL_Surface *pSurface, int x, int y)
{
    SDL_Color color;
    Uint32 col = 0; //unit32 c'est un variable pour stocker le donner brute
    char* pPosition = (char*) pSurface->pixels;

    pPosition += (pSurface->pitch * y); // oitch : nb d'octet par ligne
    pPosition += (pSurface->format->BytesPerPixel * x); // bytesperpixel taille d'1 pixel (3 ou 4 o)
    memcpy(&col, pPosition, pSurface->format->BytesPerPixel);
    SDL_GetRGB(col, pSurface->format, &color.r, &color.g, &color.b);
    return color;
}

int collisionPP(SDL_Rect pos_p, SDL_Surface *Masque)
{
    SDL_Rect pos[8]; // 8 coins de perso 

    pos[0].x = pos_p.x;
    pos[0].y = pos_p.y;
    pos[1].x = pos_p.x + pos_p.w / 2;
    pos[1].y = pos_p.y;
    pos[2].x = pos_p.x + pos_p.w;
    pos[2].y = pos_p.y;
    pos[3].x = pos_p.x;
    pos[3].y = pos_p.y + pos_p.h / 2;
    pos[4].x = pos_p.x;
    pos[4].y = pos_p.y + pos_p.h;
    pos[5].x = pos_p.x + pos_p.w / 2;
    pos[5].y = pos_p.y + pos_p.h;
    pos[6].x = pos_p.x + pos_p.w;
    pos[6].y = pos_p.y + pos_p.h;
    pos[7].x = pos_p.x + pos_p.w;
    pos[7].y = pos_p.y + pos_p.h / 2;
    // teste : haut bas droit gauche centre ..

    for (int i = 0; i < 8; i++) {
        if (pos[i].x >= 0 && pos[i].y >= 0 && pos[i].x < Masque->w && pos[i].y < Masque->h) {
            SDL_Color pixel_color = GetPixel(Masque, pos[i].x, pos[i].y);
            if (pixel_color.r == 0 && pixel_color.g == 0 && pixel_color.b == 0) {
                return 1; // Collision détectée
            }
        }
    }
    return 0; // Pas de collision
}

int CollisionParfaite(SDL_Surface *mask, SDL_Rect posPerso)
{
    return collisionPP(posPerso, mask);
}

int Collision_AABB(SDL_Rect perso, SDL_Rect objet)
{
    if ((perso.x + perso.w < objet.x) || // cote droit du perso est a gauche de l'ob
        (perso.x > objet.x + objet.w) || // cote gauche  du perso est a droite de l'ob
        (perso.y + perso.h < objet.y) || // cote bas du perso est au dessus de l'ob
        (perso.y > objet.y + objet.h)) { // cote haut du perso est en dessous de l'ob
        return 0;
    }
    return 1;
}


void ChangerMinimapNiveau(minimap *m, const char *chemin_image_minimap, SDL_Rect taille_monde)
{
    if (m->img) {
        SDL_FreeSurface(m->img);
    }

    m->img = IMG_Load(chemin_image_minimap);
    if (!m->img) {
        fprintf(stderr, "Erreur chargement nouvelle minimap : %s\n", IMG_GetError());
        return;
    }

    m->pos.w = m->img->w;
    m->pos.h = m->img->h;

    // Mise à jour des dimensions du monde réel
    m->pos2_perso.w = taille_monde.w;
    m->pos2_perso.h = taille_monde.h;
}
void deplacerEnnemi(Ennemi *ennemi, int minX, int maxX) {
    ennemi->rect.x += ennemi->vitesse * ennemi->direction; // Déplacer l'ennemi
    if (ennemi->rect.x <= minX || ennemi->rect.x + ennemi->rect.w >= maxX) {
        ennemi->direction *= -1;  // Inverser la direction si l'ennemi touche les bords
    }
}

// Fonction pour afficher l'ennemi
void afficherEnnemi(Ennemi *ennemi, SDL_Surface *screen) {
    SDL_BlitSurface(ennemi->image, NULL, screen, &ennemi->rect);
}

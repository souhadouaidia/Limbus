#ifndef MINIMAP_H
#define MINIMAP_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

// Structure pour afficher l'heure
typedef struct {
    SDL_Color color;
    TTF_Font *police;
    char ch[50];
    SDL_Surface *txt;
    SDL_Rect pos;
} text;

// Structure pour la minimap
typedef struct {
    text time;                 // Affichage de l'heure
    SDL_Surface *img;          // Image de fond de la minimap
    SDL_Rect pos;              // Position de la minimap sur l'écran
    SDL_Surface *image_perso;  // Icône représentant le joueur
    SDL_Rect pos_perso;        // Position de l'icône sur la minimap
    SDL_Rect pos2_perso;       // Position du joueur dans le monde réel
    SDL_Rect pos2_ennemi; // Position réelle de l'ennemi dans le monde
    SDL_Rect pos_ennemi;  // Position de l'ennemi sur la minimap
    SDL_Surface *image_ennemi_minimap;

} minimap;

typedef struct {
    SDL_Surface *image;
    SDL_Rect rect;
    int vitesse;
    int direction; // 1 pour droite, -1 pour gauche
} Ennemi;

void InitMinimap(minimap *m);
void AfficheMinimap(SDL_Surface *screen, minimap m);
void annimer_MiniMap(minimap *m);
void initialiser_textTemps(text *t);
SDL_Color GetPixel(SDL_Surface *pSurface, int x, int y);
int collisionPP(SDL_Rect pos_p, SDL_Surface *Masque);
int CollisionParfaite(SDL_Surface *mask, SDL_Rect posPerso);
int Collision_AABB(SDL_Rect perso, SDL_Rect objet);
void deplacerEnnemi(Ennemi *ennemi, int minX, int maxX);
void afficherEnnemi(Ennemi *ennemi, SDL_Surface *screen);
void ChangerMinimapNiveau(minimap *m, const char *chemin_image_minimap, SDL_Rect taille_monde);

#endif
